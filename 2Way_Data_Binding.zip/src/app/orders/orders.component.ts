import { Component } from '@angular/core';

@Component({
    selector: 'app-orders',
    templateUrl: './orders.component.html'
})
export class OrdersComponent {

    constructor() { }
}